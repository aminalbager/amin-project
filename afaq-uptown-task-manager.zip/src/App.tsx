import React, { useState } from 'react';
import { Plus, Edit2, Trash2, LogOut, UserPlus, CheckCircle2, Clock, CheckSquare, Calendar, Send, Mail } from 'lucide-react';

type TaskStatus = 'task' | 'ongoing' | 'done';

interface Member {
  id: string;
  name: string;
  email: string;
  description: string;
}

interface Task {
  id: string;
  title: string;
  description: string;
  dueDate: string;
  status: TaskStatus;
  assigneeId: string;
}

const INITIAL_MEMBERS: Member[] = [
  { id: '1', name: 'Ahmed Hassan', email: 'ahmed@afaq.com', description: 'Site Engineer' },
  { id: '2', name: 'Sarah Smith', email: 'sarah@afaq.com', description: 'Project Coordinator' },
];

const INITIAL_TASKS: Task[] = [
  { id: '1', title: 'Concrete Pouring', description: 'Foundation pouring for Sector A. Check weather report before start.', dueDate: '2026-03-01', status: 'task', assigneeId: '1' },
  { id: '2', title: 'Steel Rebar Inspection', description: 'Verifying the reinforcement for the ground floor columns.', dueDate: '2026-02-26', status: 'ongoing', assigneeId: '1' },
  { id: '3', title: 'Site Clearance', description: 'Removing debris from the North zone completed.', dueDate: '2026-02-20', status: 'done', assigneeId: '2' },
];

export default function App() {
  const [currentUserEmail, setCurrentUserEmail] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  
  const [members, setMembers] = useState<Member[]>(INITIAL_MEMBERS);
  const [tasks, setTasks] = useState<Task[]>(INITIAL_TASKS);
  const [selectedMemberId, setSelectedMemberId] = useState<string | null>(INITIAL_MEMBERS[0].id);

  const [isMemberModalOpen, setIsMemberModalOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<Member | null>(null);
  
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  React.useEffect(() => {
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
  }, []);

  const handleInstallApp = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setDeferredPrompt(null);
      }
    } else {
      alert('لتثبيت التطبيق، يرجى استخدام خيار "Add to Home Screen" أو "Install" من قائمة المتصفح الخاص بك.');
    }
  };

  const isAdmin = currentUserEmail === 'admin@afaq.com';
  const currentUser = members.find(m => m.email === currentUserEmail);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentUserEmail === 'admin@afaq.com' || members.some(m => m.email === currentUserEmail)) {
      setIsLoggedIn(true);
      if (currentUserEmail !== 'admin@afaq.com') {
        const user = members.find(m => m.email === currentUserEmail);
        if (user) setSelectedMemberId(user.id);
      }
    } else {
      alert('Email not found. Use admin@afaq.com for admin access, or a member email (e.g., ahmed@afaq.com) for view-only access.');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentUserEmail('');
  };

  const handleSendInvite = (member: Member) => {
    const subject = encodeURIComponent('دعوة للانضمام إلى نظام إدارة مهام AFAQ Uptown');
    const body = encodeURIComponent(`مرحباً ${member.name}،\n\nلقد تمت دعوتك للانضمام إلى نظام إدارة مهام مشروع UPTOWN التابع لشركة AFAQ.\n\nيمكنك الدخول إلى النظام باستخدام هذا البريد الإلكتروني (${member.email}) لمتابعة المهام الموكلة إليك.\n\nرابط النظام: ${window.location.origin}\n\nمع تحيات،\nمدير المشروع`);
    window.location.href = `mailto:${member.email}?subject=${subject}&body=${body}`;
  };

  const saveMember = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const memberData = {
      id: editingMember ? editingMember.id : Date.now().toString(),
      name: formData.get('name') as string,
      email: formData.get('email') as string,
      description: formData.get('description') as string,
    };

    if (editingMember) {
      setMembers(members.map(m => m.id === memberData.id ? memberData : m));
    } else {
      setMembers([...members, memberData]);
      if (confirm('هل ترغب في إرسال دعوة لهذا العضو الآن عبر البريد الإلكتروني؟\n(Would you like to send an email invitation to this member now?)')) {
        handleSendInvite(memberData);
      }
    }
    setIsMemberModalOpen(false);
    setEditingMember(null);
  };

  const deleteMember = (id: string) => {
    if (confirm('Are you sure you want to delete this member?')) {
      setMembers(members.filter(m => m.id !== id));
      setTasks(tasks.filter(t => t.assigneeId !== id));
      if (selectedMemberId === id) setSelectedMemberId(members[0]?.id || null);
    }
  };

  const saveTask = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const taskData = {
      id: editingTask ? editingTask.id : Date.now().toString(),
      title: formData.get('title') as string,
      description: formData.get('description') as string,
      dueDate: formData.get('dueDate') as string,
      status: formData.get('status') as TaskStatus,
      assigneeId: formData.get('assigneeId') as string,
    };

    if (editingTask) {
      setTasks(tasks.map(t => t.id === taskData.id ? taskData : t));
    } else {
      setTasks([...tasks, taskData]);
    }
    setIsTaskModalOpen(false);
    setEditingTask(null);
  };

  const updateTaskStatus = (taskId: string, newStatus: TaskStatus) => {
    if (!isAdmin) return;
    setTasks(tasks.map(t => t.id === taskId ? { ...t, status: newStatus } : t));
  };

  const deleteTask = (id: string) => {
    if (confirm('Are you sure you want to delete this task?')) {
      setTasks(tasks.filter(t => t.id !== id));
    }
  };

  const sendWeeklyUpdate = () => {
    alert('Weekly update sent to all team members!');
  };

  const getTaskCount = (memberId: string) => tasks.filter(t => t.assigneeId === memberId).length;

  const displayedTasks = tasks.filter(t => t.assigneeId === selectedMemberId);

  if (!isLoggedIn) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-[#4a0072] font-sans bg-no-repeat bg-center bg-fixed bg-cover"
        style={{
          backgroundImage: `linear-gradient(rgba(74, 0, 114, 0.8), rgba(74, 0, 114, 0.8)), url('https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?q=80&w=2000&auto=format&fit=crop')`
        }}
      >
        <div className="bg-white/95 backdrop-blur-md p-10 rounded-3xl shadow-2xl w-full max-w-md border border-white/20">
          <div className="text-center mb-10">
            <h1 className="text-5xl font-bold text-[#4a0072] tracking-[4px] mb-3 drop-shadow-sm">AFAQ</h1>
            <p className="text-sm text-[#6A0DAD] uppercase tracking-[3px] font-bold">Project: Uptown</p>
            <p className="text-xs text-gray-500 mt-2">Task Management System</p>
          </div>
          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">Email Address</label>
              <input 
                type="email" 
                required
                value={currentUserEmail}
                onChange={(e) => setCurrentUserEmail(e.target.value)}
                className="w-full px-5 py-3.5 rounded-xl border-2 border-gray-200 focus:ring-0 focus:border-[#6A0DAD] outline-none transition-all bg-gray-50 focus:bg-white"
                placeholder="Enter your email..."
              />
            </div>
            <button type="submit" className="w-full bg-[#6A0DAD] hover:bg-[#4a0072] text-white font-bold py-3.5 rounded-xl transition-all shadow-[0_4px_14px_0_rgba(106,13,173,0.39)] hover:shadow-[0_6px_20px_rgba(106,13,173,0.23)] hover:-translate-y-0.5">
              Login to Dashboard
            </button>
          </form>
          <div className="mt-8 pt-6 border-t border-gray-100 text-xs text-gray-400 text-center space-y-1">
            <p>Admin Access: <span className="font-bold text-gray-600">admin@afaq.com</span></p>
            <p>Member Access: <span className="font-bold text-gray-600">ahmed@afaq.com</span></p>
          </div>
          <button 
            onClick={handleInstallApp}
            className="w-full mt-4 bg-white border-2 border-[#6A0DAD] text-[#6A0DAD] hover:bg-[#f3e5f5] font-bold py-3 rounded-xl transition-all shadow-sm flex items-center justify-center gap-2"
          >
            تثبيت التطبيق كبرنامج خارجي (Install App)
          </button>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="flex h-screen w-full font-sans text-[#333] bg-no-repeat bg-center bg-fixed bg-cover"
      style={{
        backgroundImage: `linear-gradient(rgba(74, 0, 114, 0.75), rgba(74, 0, 114, 0.75)), url('https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?q=80&w=2000&auto=format&fit=crop')`
      }}
    >
      {/* Sidebar */}
      <aside className="w-[320px] bg-[#4a0072]/95 backdrop-blur-xl text-white p-6 flex flex-col shadow-2xl shrink-0 border-r border-white/10 z-10">
        <div className="text-center mb-8 border-b border-white/10 pb-8">
          <h1 className="m-0 text-4xl tracking-[6px] font-bold text-white drop-shadow-lg">AFAQ</h1>
          <p className="mt-3 text-xs opacity-90 uppercase tracking-[3px] font-bold text-[#e1bee7]">Project: Uptown</p>
        </div>
        
        <div className="flex justify-between items-center mb-5 px-2">
          <h3 className="text-xs font-bold uppercase tracking-[2px] text-[#e1bee7]">Team Members</h3>
          {isAdmin && (
            <button 
              onClick={() => { setEditingMember(null); setIsMemberModalOpen(true); }}
              className="p-2 bg-white/10 hover:bg-white/20 rounded-lg transition-colors shadow-sm"
              title="Add Member"
            >
              <UserPlus size={16} />
            </button>
          )}
        </div>
        
        <ul className="list-none p-0 m-0 space-y-3 flex-1 overflow-y-auto pr-2 custom-scrollbar">
          {members.map(member => (
            <li 
              key={member.id}
              onClick={() => setSelectedMemberId(member.id)}
              className={`p-4 rounded-2xl cursor-pointer transition-all duration-300 border ${
                selectedMemberId === member.id 
                  ? 'bg-[#9c27b0] border-white/30 shadow-[0_8px_16px_rgba(0,0,0,0.2)] scale-[1.02]' 
                  : 'bg-white/5 border-transparent hover:bg-white/10'
              }`}
            >
              <div className="flex justify-between items-start mb-2">
                <span className="block text-sm font-bold tracking-wide">{member.name}</span>
                <div className="bg-white text-[#6A0DAD] px-2.5 py-0.5 rounded-full font-bold text-[11px] min-w-[24px] text-center shadow-sm">
                  {getTaskCount(member.id)}
                </div>
              </div>
              <span className="block text-[11px] opacity-70 mb-1.5 font-medium">{member.email}</span>
              <span className="block text-[11px] text-[#e1bee7] italic">{member.description}</span>
              
              {isAdmin && (
                <div className="flex gap-2 mt-3 pt-3 border-t border-white/10">
                  <button 
                    onClick={(e) => { e.stopPropagation(); handleSendInvite(member); }}
                    className="flex-1 flex justify-center py-1.5 text-white/60 hover:text-white hover:bg-white/10 rounded-md transition-colors"
                    title="Send Invite"
                  >
                    <Mail size={14} />
                  </button>
                  <button 
                    onClick={(e) => { e.stopPropagation(); setEditingMember(member); setIsMemberModalOpen(true); }}
                    className="flex-1 flex justify-center py-1.5 text-white/60 hover:text-white hover:bg-white/10 rounded-md transition-colors"
                    title="Edit Member"
                  >
                    <Edit2 size={14} />
                  </button>
                  <button 
                    onClick={(e) => { e.stopPropagation(); deleteMember(member.id); }}
                    className="flex-1 flex justify-center py-1.5 text-white/60 hover:text-red-400 hover:bg-red-400/10 rounded-md transition-colors"
                    title="Delete Member"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              )}
            </li>
          ))}
        </ul>

        <div className="mt-6 pt-6 border-t border-white/10">
          <div className="flex items-center gap-3 mb-5 px-2 bg-white/5 p-3 rounded-xl">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#9c27b0] to-[#6A0DAD] flex items-center justify-center font-bold text-base shadow-inner border border-white/20">
              {currentUser?.name.charAt(0) || 'A'}
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="text-sm font-bold truncate">{isAdmin ? 'Administrator' : currentUser?.name}</p>
              <p className="text-[10px] text-[#e1bee7] truncate">{currentUserEmail}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button 
              onClick={handleInstallApp}
              className="flex-1 flex items-center justify-center gap-2 py-3 bg-white/10 hover:bg-white/20 rounded-xl transition-colors text-sm font-bold tracking-wide"
              title="تثبيت كبرنامج خارجي"
            >
              Install App
            </button>
            <button 
              onClick={handleLogout}
              className="flex-1 flex items-center justify-center gap-2 py-3 bg-white/10 hover:bg-red-500/20 hover:text-red-400 rounded-xl transition-colors text-sm font-bold tracking-wide"
            >
              <LogOut size={16} />
              Logout
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8 flex flex-col overflow-hidden relative">
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 bg-white/95 backdrop-blur-xl py-5 px-8 rounded-3xl border-l-[8px] border-[#6A0DAD] shadow-[0_8px_30px_rgb(0,0,0,0.12)] shrink-0 gap-4 z-10">
          <div>
            <h2 className="text-3xl font-bold text-[#4a0072] m-0 tracking-tight">Task Manager</h2>
            <p className="text-sm text-gray-500 mt-1.5 font-medium">
              {selectedMemberId ? `Viewing tasks for ${members.find(m => m.id === selectedMemberId)?.name}` : 'Select a member to view tasks'}
            </p>
          </div>
          
          <div className="flex gap-3 w-full md:w-auto">
            {isAdmin && (
              <>
                <button 
                  onClick={() => { setEditingTask(null); setIsTaskModalOpen(true); }}
                  className="flex-1 md:flex-none bg-white border-2 border-[#6A0DAD] text-[#6A0DAD] hover:bg-[#f3e5f5] py-2.5 px-5 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-sm hover:shadow-md"
                >
                  <Plus size={18} />
                  Add Task
                </button>
                <button 
                  onClick={sendWeeklyUpdate}
                  className="flex-1 md:flex-none bg-[#6A0DAD] hover:bg-[#4a0072] text-white py-2.5 px-5 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-[0_4px_14px_0_rgba(106,13,173,0.39)] hover:shadow-[0_6px_20px_rgba(106,13,173,0.23)] hover:-translate-y-0.5"
                >
                  <Send size={18} />
                  Weekly Update
                </button>
              </>
            )}
          </div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-full overflow-hidden z-10">
          {/* To-Do Column */}
          <div className="bg-white/85 backdrop-blur-xl rounded-3xl p-6 flex flex-col h-full overflow-hidden shadow-2xl border border-white/50">
            <div className="flex items-center gap-2 font-bold uppercase tracking-wider text-[#4a0072] pb-4 border-b-[3px] border-[#6A0DAD] mb-5 shrink-0">
              <CheckSquare size={20} className="text-[#6A0DAD]" />
              Task (To-Do)
              <span className="ml-auto bg-[#f3e5f5] text-[#6A0DAD] px-3 py-1 rounded-full text-xs font-bold shadow-sm">
                {displayedTasks.filter(t => t.status === 'task').length}
              </span>
            </div>
            <div className="overflow-y-auto pr-2 space-y-5 pb-4 custom-scrollbar">
              {displayedTasks.filter(t => t.status === 'task').map(task => (
                <TaskCard key={task.id} task={task} isAdmin={isAdmin} onEdit={() => { setEditingTask(task); setIsTaskModalOpen(true); }} onDelete={() => deleteTask(task.id)} onStatusChange={(s) => updateTaskStatus(task.id, s)} />
              ))}
            </div>
          </div>

          {/* On Going Column */}
          <div className="bg-white/85 backdrop-blur-xl rounded-3xl p-6 flex flex-col h-full overflow-hidden shadow-2xl border border-white/50">
            <div className="flex items-center gap-2 font-bold uppercase tracking-wider text-[#ff9800] pb-4 border-b-[3px] border-[#ff9800] mb-5 shrink-0">
              <Clock size={20} className="text-[#ff9800]" />
              On Going
              <span className="ml-auto bg-[#fff3e0] text-[#ff9800] px-3 py-1 rounded-full text-xs font-bold shadow-sm">
                {displayedTasks.filter(t => t.status === 'ongoing').length}
              </span>
            </div>
            <div className="overflow-y-auto pr-2 space-y-5 pb-4 custom-scrollbar">
              {displayedTasks.filter(t => t.status === 'ongoing').map(task => (
                <TaskCard key={task.id} task={task} isAdmin={isAdmin} onEdit={() => { setEditingTask(task); setIsTaskModalOpen(true); }} onDelete={() => deleteTask(task.id)} onStatusChange={(s) => updateTaskStatus(task.id, s)} />
              ))}
            </div>
          </div>

          {/* Done Column */}
          <div className="bg-white/85 backdrop-blur-xl rounded-3xl p-6 flex flex-col h-full overflow-hidden shadow-2xl border border-white/50">
            <div className="flex items-center gap-2 font-bold uppercase tracking-wider text-[#4caf50] pb-4 border-b-[3px] border-[#4caf50] mb-5 shrink-0">
              <CheckCircle2 size={20} className="text-[#4caf50]" />
              Done
              <span className="ml-auto bg-[#e8f5e9] text-[#4caf50] px-3 py-1 rounded-full text-xs font-bold shadow-sm">
                {displayedTasks.filter(t => t.status === 'done').length}
              </span>
            </div>
            <div className="overflow-y-auto pr-2 space-y-5 pb-4 custom-scrollbar">
              {displayedTasks.filter(t => t.status === 'done').map(task => (
                <TaskCard key={task.id} task={task} isAdmin={isAdmin} onEdit={() => { setEditingTask(task); setIsTaskModalOpen(true); }} onDelete={() => deleteTask(task.id)} onStatusChange={(s) => updateTaskStatus(task.id, s)} />
              ))}
            </div>
          </div>
        </div>
      </main>

      {/* Modals */}
      {isMemberModalOpen && (
        <div className="fixed inset-0 bg-[#4a0072]/40 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 w-full max-w-md shadow-[0_20px_50px_rgba(0,0,0,0.3)] border border-white/20">
            <h2 className="text-2xl font-bold text-[#4a0072] mb-6 tracking-tight">{editingMember ? 'Edit Member' : 'Add New Member'}</h2>
            <form onSubmit={saveMember} className="space-y-5">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Full Name</label>
                <input name="name" defaultValue={editingMember?.name} required className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:ring-0 focus:border-[#6A0DAD] outline-none transition-colors bg-gray-50 focus:bg-white" placeholder="e.g. Ahmed Hassan" />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Email Address</label>
                <input name="email" type="email" defaultValue={editingMember?.email} required className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:ring-0 focus:border-[#6A0DAD] outline-none transition-colors bg-gray-50 focus:bg-white" placeholder="e.g. ahmed@afaq.com" />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Role / Description</label>
                <input name="description" defaultValue={editingMember?.description} required className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:ring-0 focus:border-[#6A0DAD] outline-none transition-colors bg-gray-50 focus:bg-white" placeholder="e.g. Site Engineer" />
              </div>
              <div className="flex gap-3 mt-8 pt-4 border-t border-gray-100">
                <button type="button" onClick={() => setIsMemberModalOpen(false)} className="flex-1 py-3 border-2 border-gray-200 text-gray-700 rounded-xl font-bold hover:bg-gray-50 transition-colors">Cancel</button>
                <button type="submit" className="flex-1 py-3 bg-[#6A0DAD] text-white rounded-xl font-bold hover:bg-[#4a0072] transition-colors shadow-md">Save Member</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isTaskModalOpen && (
        <div className="fixed inset-0 bg-[#4a0072]/40 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 w-full max-w-lg shadow-[0_20px_50px_rgba(0,0,0,0.3)] border border-white/20">
            <h2 className="text-2xl font-bold text-[#4a0072] mb-6 tracking-tight">{editingTask ? 'Edit Task' : 'Add New Task'}</h2>
            <form onSubmit={saveTask} className="space-y-5">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Task Title</label>
                <input name="title" defaultValue={editingTask?.title} required className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:ring-0 focus:border-[#6A0DAD] outline-none transition-colors bg-gray-50 focus:bg-white" placeholder="e.g. Concrete Pouring" />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Description</label>
                <textarea name="description" defaultValue={editingTask?.description} required rows={3} className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:ring-0 focus:border-[#6A0DAD] outline-none transition-colors bg-gray-50 focus:bg-white resize-none" placeholder="Task details..." />
              </div>
              <div className="grid grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Due Date</label>
                  <input name="dueDate" type="date" defaultValue={editingTask?.dueDate} required className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:ring-0 focus:border-[#6A0DAD] outline-none transition-colors bg-gray-50 focus:bg-white" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Status</label>
                  <select name="status" defaultValue={editingTask?.status || 'task'} className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:ring-0 focus:border-[#6A0DAD] outline-none transition-colors bg-gray-50 focus:bg-white cursor-pointer">
                    <option value="task">To-Do (Task)</option>
                    <option value="ongoing">On Going</option>
                    <option value="done">Done</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Assign To</label>
                <select name="assigneeId" defaultValue={editingTask?.assigneeId || selectedMemberId || ''} required className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:ring-0 focus:border-[#6A0DAD] outline-none transition-colors bg-gray-50 focus:bg-white cursor-pointer">
                  {members.map(m => (
                    <option key={m.id} value={m.id}>{m.name}</option>
                  ))}
                </select>
              </div>
              <div className="flex gap-3 mt-8 pt-4 border-t border-gray-100">
                <button type="button" onClick={() => setIsTaskModalOpen(false)} className="flex-1 py-3 border-2 border-gray-200 text-gray-700 rounded-xl font-bold hover:bg-gray-50 transition-colors">Cancel</button>
                <button type="submit" className="flex-1 py-3 bg-[#6A0DAD] text-white rounded-xl font-bold hover:bg-[#4a0072] transition-colors shadow-md">Save Task</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

function TaskCard({ task, isAdmin, onEdit, onDelete, onStatusChange }: { key?: React.Key, task: Task, isAdmin: boolean, onEdit: () => void, onDelete: () => void, onStatusChange: (s: TaskStatus) => void }) {
  const borderColor = task.status === 'task' ? 'border-[#6A0DAD]' : task.status === 'ongoing' ? 'border-[#ff9800]' : 'border-[#4caf50]';
  const titleColor = task.status === 'task' ? 'text-[#6A0DAD]' : task.status === 'ongoing' ? 'text-[#ff9800]' : 'text-[#4caf50]';

  return (
    <div className={`bg-white rounded-2xl p-5 shadow-sm hover:shadow-md transition-all border-t-[6px] ${borderColor} group relative`}>
      <h4 className={`m-0 mb-2.5 font-bold text-[15px] pr-8 leading-tight ${titleColor}`}>{task.title}</h4>
      <p className="text-[13px] m-0 mb-5 leading-relaxed text-gray-600">{task.description}</p>
      
      <div className="flex flex-col gap-3">
        <div className="flex items-center gap-2 text-[11px] text-gray-500 bg-gray-50/80 p-2.5 rounded-lg border border-gray-100">
          <Calendar size={14} className="text-gray-400" />
          <span className="font-bold tracking-wide uppercase">Due: {task.dueDate}</span>
        </div>
        
        {isAdmin && (
          <div className="flex items-center justify-between pt-3 border-t border-gray-100">
            <select 
              value={task.status}
              onChange={(e) => onStatusChange(e.target.value as TaskStatus)}
              className="text-xs font-bold border-2 border-gray-100 rounded-lg px-2 py-1.5 bg-white outline-none focus:border-[#6A0DAD] cursor-pointer text-gray-700"
            >
              <option value="task">To-Do</option>
              <option value="ongoing">On Going</option>
              <option value="done">Done</option>
            </select>
            
            <div className="flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
              <button onClick={onEdit} className="p-1.5 text-gray-400 hover:text-[#6A0DAD] hover:bg-[#f3e5f5] rounded-lg transition-colors">
                <Edit2 size={14} />
              </button>
              <button onClick={onDelete} className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                <Trash2 size={14} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
